﻿using Rpg22.Scenes;

namespace Rpg22
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Game game = new Game();
            game.Run();            
        }
    }
}
