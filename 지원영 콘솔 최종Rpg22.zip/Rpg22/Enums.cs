﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Rpg22
{
    public enum SceneType { Title, Select, Town, Battle, Inventory, Shop, GameOver, Size }

    public enum Job { Warrior = 1, Mage, Rogue }
}
